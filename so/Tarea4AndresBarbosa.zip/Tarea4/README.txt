nombre: Andres Luisos Barbosa Carranza
n_cuenta: 313055407

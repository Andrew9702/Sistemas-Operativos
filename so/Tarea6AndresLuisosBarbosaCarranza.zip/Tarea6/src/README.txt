Alumno: Andrés Luisos Barbosa Carranza

n_cuenta: 313055407

El programa recibe el nombre del archivo puede ser entre comillas o comillas simples o simplemente sin comillas, se tiene que ingresar la bandera y en caso de buscar un archivo, el nombre de este.

Así el programa imprime la ruta del archivo seguido de la palabra encontrado!, en caso de que el archivo no exista, simplemente imprimirá no encontrado!
